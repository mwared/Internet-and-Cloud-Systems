"""
Weather-Giphy App
"""
import requests, os
import urllib, json
import urllib.request
from flask import Flask, render_template, request

#my weather-giphy app
app = Flask(__name__)       

#home page
@app.route('/')
def index():                                    
    return render_template('index.html')

#results page
@app.route ('/results', methods=['POST'])       
def render_results():
    zipCode = request.form['zip']
    
    #weather api key
    key = '48bb1a3ada8af5b4d943ce6dfd3d3ed8'   
    
    #giphy api key 
    apiKey = 'Uxx9VzAEKFlv4z8JcWNZLUPZTTtfrs76'
    
    data = tempertaure (zipCode, key)
   
    #parsing the tempertaure from the api call
    temp = data["main"]["temp"] 

    #parsing name of the city/ country where the zip code is in                
    name = data["name"]           

    #parsing the weather to use in giphy              
    weather = data["weather"][0]["description"] 

    #gif holds the weather string we get back from the weather app
    gif = weather

    data = giphy_weather (apiKey, gif)
    
    gifImages = data["data"][0]["images"]["original"]["url"] 

    word = request.form['q']
    
    data = giphy (apiKey, word)
    
    images  = data["data"][0]["images"]["original"]["url"] 
    
    #rendering the results page
    return render_template('results.html', temp=temp,  name=name, weather=weather, gifImages=gifImages , images=images)

#parsing the weather api    
def tempertaure (zipCode, key):
    key = '48bb1a3ada8af5b4d943ce6dfd3d3ed8'
    url = "http://api.openweathermap.org/data/2.5/weather?zip={}&units=imperial&appid={}".format(zipCode, key)
    r = requests.get(url)
    return r.json() 

#parsing the giphy api and return to be used to replace "q" with the current weather
def giphy_weather (apiKey, gif):
    apiKey = 'Uxx9VzAEKFlv4z8JcWNZLUPZTTtfrs76'    
    with urllib.request.urlopen("https://api.giphy.com/v1/gifs/search?api_key={}&q={}".format(apiKey, gif.replace(" ", "-"))) as response:
        r = json.loads(response.read())
    return r

#parsing the giphy api and return to be used to replace "word" with user's input
def giphy (apiKey, word):
    apiKey = 'Uxx9VzAEKFlv4z8JcWNZLUPZTTtfrs76'    
    with urllib.request.urlopen("https://api.giphy.com/v1/gifs/search?api_key={}&q={}".format(apiKey, word.replace(" ", "-"))) as response:
        r = json.loads(response.read())
    return r

if __name__ == '__main__':
    app.run(host='0.0.0.0',port=int(os.environ.get('PORT',5000)))
