# <div align="center">cloud-f20-Mano-Wared-mwared</div>

# Internet, Web, & Cloud Systems

## General Information
- Author: Mano Wared
- Class: CS 430/530
- Assignment:
	- [x] Homework #1
	- [x] Homework #2
	- [x] Homework #3
	- [ ] Homework #4

