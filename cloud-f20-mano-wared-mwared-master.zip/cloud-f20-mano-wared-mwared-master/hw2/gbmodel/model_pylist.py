"""
Python list model
"""
from datetime import date
from .Model import Model

class model(Model):
    def __init__(self):
        self.charity_entries = []

    def select(self):
        """
        Returns charity_entries list of lists
        Each list in charity_entries name, number, address, services, hours, reviews, donation, date
        :return: List of lists
        """
        return self.charity_entries

    def insert(self, name, number, address, services, hours, reviews, donation):
        """
        Appends a new list of values representing new message into charity_entries
        :param name: String
        :param number: Integer
        :param address: String
	:param services: String
        :param hours: String
        :param reviews: String
	:param donation: Float
	:return: True
        """
        params = [name, number, address, services, hours, reviews, donation, date.today()]
        self.charity_entries.append(params)
        return True
