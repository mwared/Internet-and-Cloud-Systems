class Model():
    def select(self):
        """
        Gets all entries from the database
        :return: Tuple containing all rows of database
        """
        pass

    def insert(self, name, number, address, services, hours, reviews, donation):
        """
        Inserts entry into database
        :param name: String
        :param number: Integer
	:param address: String
	:param services: String
	:param hours: String 	
	:param reviews: String
	:param donation: Float
        :return: none
        :raises: Database errors on connection and insertion
        """
        pass
