from flask import render_template
from flask.views import MethodView
import gbmodel

class Index(MethodView):
    def get(self):
        model = gbmodel.get_model()
        entries = [dict(name=row[0], number=row[1], adress=row[2],services=row[3],
			hours=row[4], reviews=row[5], donation=row[6], signed_on=row[7]) for row in model.select()]
        return render_template('index.html',entries=entries)
